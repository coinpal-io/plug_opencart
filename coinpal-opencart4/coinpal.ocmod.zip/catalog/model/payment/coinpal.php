<?php
namespace Opencart\Catalog\Model\Extension\Coinpal\Payment;

class Coinpal extends \Opencart\System\Engine\Model {
	public function getMethods(array $address = []): array {
		$this->load->language('extension/coinpal/payment/coinpal');

		if (!$this->config->get('payment_coinpal_status')) {
			return [];
		}

		if ($this->cart->hasSubscription()) {
			return [];
		}

		$total = (float)$this->config->get('payment_coinpal_total');

		if ($total > 0 && $this->cart->getTotal() < $total) {
			return [];
		}

		if (!$this->config->get('config_checkout_payment_address')) {
			$status = true;
		} elseif (!(int)$this->config->get('payment_coinpal_geo_zone_id')) {
			$status = true;
		} else {
			$this->load->model('localisation/geo_zone');

			$results = $this->model_localisation_geo_zone->getGeoZone(
				(int)$this->config->get('payment_coinpal_geo_zone_id'),
				(int)($address['country_id'] ?? 0),
				(int)($address['zone_id'] ?? 0)
			);

			$status = (bool)$results;
		}

		if (!$status) {
			return [];
		}

		$title = (string)$this->config->get('payment_coinpal_currtitle');

		if ($title === '') {
			$title = $this->language->get('text_title');
		}

		return [
			'code' => 'coinpal',
			'name' => $title,
			'option' => [
				'coinpal' => [
					'code' => 'coinpal.coinpal',
					'name' => $title
				]
			],
			'sort_order' => (int)$this->config->get('payment_coinpal_sort_order')
		];
	}
}
