<?php
namespace Opencart\Catalog\Controller\Extension\Coinpal\Payment;

class Coinpal extends \Opencart\System\Engine\Controller {
	private const LIVE_GATEWAY_URL = 'https://pay.coinpal.io/gateway/pay/checkout';
	private const TEST_GATEWAY_URL = 'https://pay.coinpal.io/gateway/pay/checkout';
	private const CURL_TIMEOUT = 30;
	private const CURL_CONNECT_TIMEOUT = 10;

	public function index(): string {
		$this->load->language('extension/coinpal/payment/coinpal');

		$data['button_confirm'] = $this->language->get('button_confirm');
		$data['text_instruction'] = $this->language->get('text_instruction');
		$data['text_description'] = $this->language->get('text_description');
		$data['text_payment'] = $this->language->get('text_payment');
		$data['language'] = $this->config->get('config_language');

		return $this->load->view('extension/coinpal/payment/coinpal', $data);
	}

	public function confirm(): void {
		$this->load->language('extension/coinpal/payment/coinpal');

		$json = [];

		if (empty($this->session->data['order_id'])) {
			$json['error'] = $this->language->get('error_order');
		}

		if (!isset($this->session->data['payment_method']) || ($this->session->data['payment_method']['code'] ?? '') !== 'coinpal.coinpal') {
			$json['error'] = $this->language->get('error_payment_method');
		}

		$this->load->model('checkout/order');

		if (!$json) {
			$order_info = $this->model_checkout_order->getOrder((int)$this->session->data['order_id']);

			if (!$order_info) {
				$json['redirect'] = $this->url->link('checkout/failure', 'language=' . $this->config->get('config_language'), true);
			}
		}

		if (!$json && !empty($order_info) && !$this->hasRequiredConfig()) {
			$json['error'] = $this->language->get('error_config');
		}

		if (!$json && !empty($order_info)) {
			$order_no = $this->buildOrderNo((int)$order_info['order_id']);
			$params = $this->buildParams($order_info, $order_no);

			$this->model_checkout_order->addHistory(
				(int)$order_info['order_id'],
				$this->resolveStatusId('unpaid'),
				'Order created',
				false
			);

			$this->writeDbLog($order_no, 'beforehand order get url param:' . $this->encodeLogData($params));
			$this->writeFileLog('#order' . $order_no . ' beforehand order get url param:' . $this->encodeLogData($params));

			$response = $this->requestCheckout($this->getGatewayUrl(), $params);

			$this->writeDbLog($order_no, 'url:' . $this->getGatewayUrl() . ' beforehand order paycurl:' . $response['body']);
			$this->writeFileLog('beforehand order payment url:' . $this->getGatewayUrl() . ' method:post Request:' . $this->encodeLogData($params) . ' Result:' . $response['body']);

			if ($response['http_code'] != 200 || empty($response['data']['nextStepContent'])) {
				$message = $response['data']['respMessage'] ?? $response['error'] ?? $this->language->get('error_request');
				$json['redirect'] = $this->url->link(
					'extension/coinpal/payment/coinpal.failure',
					'language=' . $this->config->get('config_language') . '&message=' . urlencode($message),
					true
				);
			} else {
				$json['redirect'] = $this->appendQueryParams($response['data']['nextStepContent'], ['source' => 'opencart']);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function failure(): void {
		$this->load->language('checkout/failure');
		$this->load->language('extension/coinpal/payment/coinpal');

		$this->document->setTitle($this->language->get('text_failure_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home', 'language=' . $this->config->get('config_language'))
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_basket'),
			'href' => $this->url->link('checkout/cart', 'language=' . $this->config->get('config_language'))
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_checkout'),
			'href' => $this->url->link('checkout/checkout', 'language=' . $this->config->get('config_language'), true)
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_failure_title'),
			'href' => $this->url->link('extension/coinpal/payment/coinpal.failure', 'language=' . $this->config->get('config_language'), true)
		];

		$message = $this->request->get['message'] ?? $this->language->get('text_failure_default');
		$message = htmlspecialchars((string)$message, ENT_QUOTES, 'UTF-8');

		$data['heading_title'] = $this->language->get('text_failure_title');
		$data['text_message'] = sprintf($this->language->get('text_failure_message'), $message);
		$data['button_continue'] = $this->language->get('button_continue');
		$data['continue'] = $this->url->link('checkout/checkout', 'language=' . $this->config->get('config_language'), true);

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		$this->response->setOutput($this->load->view('extension/coinpal/payment/coinpal_failure', $data));
	}

	public function notify(): void {
		$this->load->language('extension/coinpal/payment/coinpal');
		$this->load->model('checkout/order');

		$order_no = (string)($this->request->post['orderNo'] ?? '');
		$order_id = $this->extractOrderId($order_no);

		try {
			$this->writeDbLog((string)$order_id, 'notify:' . $this->encodeLogData($this->request->post));

			if (!$this->request->post || !$this->validateSignature($this->request->post)) {
				$comment = $this->language->get('text_pw_mismatch');

				if ($order_id) {
					$this->model_checkout_order->addHistory($order_id, $this->resolveStatusId('failed'), $comment, false);
				}

				$this->writeFileLog('Validation failed Result:' . $this->encodeLogData($this->request->post));
				$this->writeDbLog((string)$order_id, 'Validation failed Result:' . $this->encodeLogData($this->request->post));
				$this->response->setOutput('verify failed');

				return;
			}

			$state = (string)($this->request->post['status'] ?? '');

			if ($state === 'partial_paid') {
				$state = 'partial';
			}

			$comment = $this->buildNotifyComment($this->request->post);
			$status_id = $this->resolveStatusId($state);
			$order_info = $order_id ? $this->model_checkout_order->getOrder($order_id) : [];

			if ($order_id && $order_info && (int)$order_info['order_status_id'] !== $status_id) {
				$this->model_checkout_order->addHistory($order_id, $status_id, $comment, false);
			}

			$this->writeFileLog('notify log orderid:' . $order_id . ' status:' . $status_id . ' message:' . $comment);
			$this->writeDbLog((string)$order_id, 'notify orderid:' . $order_id . ' s:' . $status_id . ' m:' . $comment);
			$this->response->setOutput('success');
		} catch (\Throwable $exception) {
			$this->writeFileLog('notify Exception:' . $exception->getMessage());
			$this->writeDbLog((string)$order_id, 'notify Exception:' . $exception->getMessage());

			if ($order_id) {
				$this->model_checkout_order->addHistory($order_id, $this->resolveStatusId('failed'), $this->language->get('text_pw_mismatch'), false);
			}

			$this->response->setOutput('verify failed');
		}
	}

	private function buildParams(array $order_info, string $order_no): array {
		$params = [
			'version' => '2.1',
			'requestId' => $order_no,
			'merchantNo' => (string)$this->config->get('payment_coinpal_merchantid'),
			'orderNo' => $order_no,
			'orderCurrencyType' => 'fiat',
			'orderAmount' => $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false),
			'orderCurrency' => $order_info['currency_code'],
			'payerEmail' => $order_info['email'],
			'payerIP' => $this->request->server['REMOTE_ADDR'] ?? '',
			'successUrl' => $this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true),
			'redirectURL' => $this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true),
			'cancelURL' => $this->url->link(
				'extension/coinpal/payment/coinpal.failure',
				'language=' . $this->config->get('config_language') . '&message=' . urlencode($this->language->get('text_cancelled')),
				true
			),
			'notifyURL' => $this->url->link('extension/coinpal/payment/coinpal.notify', '', true)
		];

		$params['sign'] = hash(
			'sha256',
			(string)$this->config->get('payment_coinpal_secretkey') .
			$params['requestId'] .
			$params['merchantNo'] .
			$params['orderNo'] .
			$params['orderAmount'] .
			$params['orderCurrency']
		);

		return $params;
	}

	private function getGatewayUrl(): string {
		if ((string)$this->config->get('payment_coinpal_test') === '1') {
			return self::TEST_GATEWAY_URL;
		}

		return self::LIVE_GATEWAY_URL;
	}

	private function requestCheckout(string $url, array $params): array {
		if (!function_exists('curl_init')) {
			return [
				'http_code' => 0,
				'body' => '',
				'data' => [],
				'error' => 'cURL extension is not available'
			];
		}

		$ch = curl_init($url);

		curl_setopt_array($ch, [
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS => http_build_query($params),
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_HEADER => false,
			CURLOPT_USERAGENT => 'Coinpal/OpenCart4',
			CURLOPT_ENCODING => 'gzip,deflate',
			CURLOPT_CONNECTTIMEOUT => self::CURL_CONNECT_TIMEOUT,
			CURLOPT_TIMEOUT => self::CURL_TIMEOUT,
			CURLOPT_HTTPHEADER => [
				'Accept: application/json, text/html, application/xhtml+xml, application/xml',
				'Accept-Language: en-US,en',
				'Pragma: no-cache',
				'Cache-Control: no-cache'
			]
		]);

		if (strpos($url, 'https://') === 0) {
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		}

		$body = (string)curl_exec($ch);
		$error = curl_errno($ch) ? curl_error($ch) : '';
		$http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);

		curl_close($ch);

		$data = json_decode($body, true);

		return [
			'http_code' => $http_code,
			'body' => $body,
			'data' => is_array($data) ? $data : [],
			'error' => $error
		];
	}

	private function validateSignature(array $params): bool {
		$required = ['requestId', 'merchantNo', 'orderNo', 'orderAmount', 'orderCurrency', 'sign'];

		foreach ($required as $key) {
			if (!isset($params[$key])) {
				return false;
			}
		}

		$sign = hash(
			'sha256',
			(string)$this->config->get('payment_coinpal_secretkey') .
			$params['requestId'] .
			$params['merchantNo'] .
			$params['orderNo'] .
			$params['orderAmount'] .
			$params['orderCurrency']
		);

		return hash_equals($sign, (string)$params['sign']);
	}

	private function buildNotifyComment(array $payload): string {
		$fields = ['status', 'orderNo', 'orderAmount', 'orderCurrency', 'reference', 'sign'];
		$comment = [];

		foreach ($fields as $field) {
			if (isset($payload[$field])) {
				$comment[] = $field . ': ' . $payload[$field];
			}
		}

		return implode("\n", $comment);
	}

	private function resolveStatusId(string $status): int {
		$map = [
			'unpaid' => (int)$this->config->get('payment_coinpal_unpaid_status_id'),
			'partial' => (int)$this->config->get('payment_coinpal_partial_status_id'),
			'paid' => (int)$this->config->get('payment_coinpal_paid_status_id'),
			'pending' => (int)$this->config->get('payment_coinpal_pending_status_id'),
			'cancelled' => (int)$this->config->get('payment_coinpal_cancelled_status_id'),
			'failed' => (int)$this->config->get('payment_coinpal_failed_status_id'),
			'refunding' => (int)$this->config->get('payment_coinpal_refunding_status_id'),
			'refunded' => (int)$this->config->get('payment_coinpal_refunded_status_id'),
			'complaint' => (int)$this->config->get('payment_coinpal_complaint_status_id'),
			'chargeback' => (int)$this->config->get('payment_coinpal_chargeback_status_id')
		];

		if (!empty($map[$status])) {
			return $map[$status];
		}

		if (!empty($map['failed'])) {
			return $map['failed'];
		}

		return (int)$this->config->get('config_order_status_id');
	}

	private function buildOrderNo(int $order_id): string {
		return 'OC' . $order_id . random_int(10000000, 99999999);
	}

	private function extractOrderId(string $order_no): int {
		if ($order_no === '') {
			return 0;
		}

		$order_no = str_replace('OC', '', $order_no);

		if (strlen($order_no) > 8) {
			$order_no = substr($order_no, 0, -8);
		}

		return (int)$order_no;
	}

	private function appendQueryParams(string $url, array $params): string {
		if (!$params) {
			return $url;
		}

		$fragment = '';
		$fragment_pos = strpos($url, '#');

		if ($fragment_pos !== false) {
			$fragment = substr($url, $fragment_pos);
			$url = substr($url, 0, $fragment_pos);
		}

		$separator = strpos($url, '?') === false ? '?' : '&';

		return $url . $separator . http_build_query($params) . $fragment;
	}

	private function writeDbLog(string $order_id, string $message): void {
		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "coinpal_log` (
				`id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
				`id_order` varchar(50) NOT NULL,
				`message` text NOT NULL,
				`date_add` datetime NOT NULL,
				PRIMARY KEY (`id_log`),
				KEY `id_order` (`id_order`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
		");

		$this->db->query("
			INSERT INTO `" . DB_PREFIX . "coinpal_log`
			SET `id_order` = '" . $this->db->escape($order_id) . "',
			    `message` = '" . $this->db->escape($message) . "',
			    `date_add` = NOW()
		");
	}

	private function writeFileLog(string $message): void {
		$logger = new \Opencart\System\Library\Log('coinpal.log');
		$logger->write($message);
	}

	private function hasRequiredConfig(): bool {
		return
			(string)$this->config->get('payment_coinpal_merchantid') !== '' &&
			(string)$this->config->get('payment_coinpal_secretkey') !== '';
	}

	private function encodeLogData($data): string {
		return json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	}
}
