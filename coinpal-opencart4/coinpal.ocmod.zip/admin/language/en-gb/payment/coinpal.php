<?php
$_['heading_title']                = 'Coinpal';
$_['text_extension']               = 'Extensions';
$_['text_success']                 = 'Success: You have modified Coinpal account details!';
$_['text_edit']                    = 'Edit Coinpal';
$_['text_enabled']                 = 'Enabled';
$_['text_disabled']                = 'Disabled';
$_['text_testmode_on']             = 'On';
$_['text_testmode_off']            = 'Off';
$_['text_all_zones']               = 'All Zones';
$_['text_terminal_coinpal']        = 'coinpal';
$_['text_terminal_coinpalpayment'] = 'coinpalpayment';
$_['text_coinpal']                 = '<img width="180" height="40" src="../extension/coinpal/admin/view/image/payment/Coinpal.png" alt="Coinpal" title="Coinpal" style="border: 1px solid #EEEEEE;" />';

$_['entry_currtitle']              = 'Method Title';
$_['entry_merchantid']             = 'Merchant ID';
$_['entry_email']                  = 'Clocash Email';
$_['entry_secretkey']              = 'Secret Key';
$_['entry_appid']                  = 'Application ID';
$_['entry_method']                 = 'Payment Method';
$_['entry_3ds']                    = 'Enable 3DS';
$_['entry_terminal']               = 'Terminal';
$_['entry_test']                   = 'Test Mode';
$_['entry_total']                  = 'Total';
$_['entry_unpaid_status']          = 'Unpaid Status';
$_['entry_paid_status']            = 'Paid Status';
$_['entry_pending_status']         = 'Pending Status';
$_['entry_cancelled_status']       = 'Cancelled Status';
$_['entry_failed_status']          = 'Failed Status';
$_['entry_refunding_status']       = 'Refunding Status';
$_['entry_refunded_status']        = 'Refunded Status';
$_['entry_complaint_status']       = 'Complaint Status';
$_['entry_chargeback_status']      = 'Chargeback Status';
$_['entry_partial_status']         = 'Partial Paid Status';
$_['entry_geo_zone']               = 'Geo Zone';
$_['entry_status']                 = 'Status';
$_['entry_sort_order']             = 'Sort Order';

$_['help_total']                   = 'Checkout total required before this payment method becomes active.';

$_['error_permission']             = 'Warning: You do not have permission to modify payment Coinpal!';
$_['error_email']                  = 'Clocash Email required!';
$_['error_secretkey']              = 'Secret Key required!';
$_['error_appid']                  = 'Application ID required!';
$_['error_currtitle']              = 'Method Title required!';
$_['error_merchantid']             = 'Merchant ID required!';
$_['error_total']                  = 'Total must be a valid number!';
