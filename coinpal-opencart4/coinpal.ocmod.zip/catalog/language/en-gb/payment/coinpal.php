<?php
$_['heading_title']             = 'Coinpal';
$_['text_title']                = 'Pay Crypto with Coinpal';
$_['text_title_poliau']         = 'Australia bank transfer';
$_['text_title_polinz']         = 'New Zealand bank transfer';
$_['text_title_itau']           = 'Banco Itau';
$_['text_title_bancodobrasil']  = 'Banco do Brasil';
$_['text_title_santandermx']    = 'Santander Mexico';
$_['text_title_banktransferjp'] = 'Bank Transfer';
$_['text_title_konbinijp']      = 'Convenience Store Payment (Konbini)';
$_['text_title_payeasyjp']      = 'PayEasy';
$_['text_title_webmoneyjp']     = 'WebMoney Japan';
$_['text_title_openbucks']      = 'Pay with Gift Cards using Openbucks';
$_['text_title_trustpay']       = 'European bank transfer';
$_['text_instruction']          = 'Secure cryptocurrency checkout';
$_['text_description']          = 'You will be redirected to Coinpal to complete your payment.';
$_['text_payment']              = 'Click Confirm Order to continue to Coinpal.';
$_['text_success']              = 'Your payment was successfully received.';
$_['text_failure']              = 'Your payment has not been received yet. Please wait up to 10 minutes if you have already paid.';
$_['text_failure_title']        = 'Payment failed';
$_['text_failure_message']      = '<p>There was a problem processing your payment and the order did not complete.</p><p>Possible reasons are: <b>%s</b></p>';
$_['text_failure_default']      = 'Unable to create Coinpal checkout.';
$_['text_cancelled']            = 'Payment cancelled';
$_['text_pw_mismatch']          = 'CallbackPW does not match. Order requires investigation.';

$_['button_confirm']            = 'Confirm Order';

$_['error_order']               = 'Order not found.';
$_['error_payment_method']      = 'Invalid payment method.';
$_['error_request']             = 'Request to Coinpal failed.';
$_['error_config']              = 'Coinpal is not configured correctly. Please contact the store administrator.';
