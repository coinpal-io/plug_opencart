<?php
namespace Opencart\Admin\Controller\Extension\Coinpal\Payment;

class Coinpal extends \Opencart\System\Engine\Controller {
	private const CONFIG_DEFAULTS = [
		'payment_coinpal_currtitle' => 'Crypto-Currency',
		'payment_coinpal_merchantid' => '',
		'payment_coinpal_secretkey' => '',
		'payment_coinpal_email' => '',
		'payment_coinpal_appid' => '',
		'payment_coinpal_method' => '',
		'payment_coinpal_3ds' => '0',
		'payment_coinpal_terminal' => 'coinpal',
		'payment_coinpal_test' => '0',
		'payment_coinpal_total' => '0',
		'payment_coinpal_unpaid_status_id' => 0,
		'payment_coinpal_partial_status_id' => 0,
		'payment_coinpal_paid_status_id' => 0,
		'payment_coinpal_pending_status_id' => 0,
		'payment_coinpal_cancelled_status_id' => 0,
		'payment_coinpal_failed_status_id' => 0,
		'payment_coinpal_refunding_status_id' => 0,
		'payment_coinpal_refunded_status_id' => 0,
		'payment_coinpal_complaint_status_id' => 0,
		'payment_coinpal_chargeback_status_id' => 0,
		'payment_coinpal_geo_zone_id' => 0,
		'payment_coinpal_status' => '0',
		'payment_coinpal_sort_order' => '0'
	];

	public function index(): void {
		$this->load->language('extension/coinpal/payment/coinpal');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/coinpal/payment/coinpal', 'user_token=' . $this->session->data['user_token'])
		];

		$data['save'] = $this->url->link('extension/coinpal/payment/coinpal.save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

		foreach (self::CONFIG_DEFAULTS as $key => $default) {
			$data[$key] = $this->config->get($key) !== null ? $this->config->get($key) : $default;
		}

		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		$this->load->model('localisation/geo_zone');
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/coinpal/payment/coinpal', $data));
	}

	public function save(): void {
		$this->load->language('extension/coinpal/payment/coinpal');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/coinpal/payment/coinpal')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		if (empty($this->request->post['payment_coinpal_currtitle'])) {
			$json['error']['currtitle'] = $this->language->get('error_currtitle');
		}

		if (empty($this->request->post['payment_coinpal_merchantid'])) {
			$json['error']['merchantid'] = $this->language->get('error_merchantid');
		}

		if (empty($this->request->post['payment_coinpal_secretkey'])) {
			$json['error']['secretkey'] = $this->language->get('error_secretkey');
		}

		if (
			isset($this->request->post['payment_coinpal_total']) &&
			$this->request->post['payment_coinpal_total'] !== '' &&
			!is_numeric($this->request->post['payment_coinpal_total'])
		) {
			$json['error']['total'] = $this->language->get('error_total');
		}

		if (!$json) {
			$this->load->model('setting/setting');
			$this->model_setting_setting->editSetting('payment_coinpal', $this->normalizePostData($this->request->post));
			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function install(): void {
		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "coinpal_log` (
				`id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
				`id_order` varchar(50) NOT NULL,
				`message` text NOT NULL,
				`date_add` datetime NOT NULL,
				PRIMARY KEY (`id_log`),
				KEY `id_order` (`id_order`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
		");
	}

	public function uninstall(): void {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "coinpal_log`");
	}

	private function normalizePostData(array $post): array {
		$data = self::CONFIG_DEFAULTS;

		foreach (array_keys(self::CONFIG_DEFAULTS) as $key) {
			if (!array_key_exists($key, $post)) {
				continue;
			}

			$value = $post[$key];

			if (is_string($value)) {
				$value = trim($value);
			}

			$data[$key] = $value;
		}

		$int_keys = [
			'payment_coinpal_unpaid_status_id',
			'payment_coinpal_partial_status_id',
			'payment_coinpal_paid_status_id',
			'payment_coinpal_pending_status_id',
			'payment_coinpal_cancelled_status_id',
			'payment_coinpal_failed_status_id',
			'payment_coinpal_refunding_status_id',
			'payment_coinpal_refunded_status_id',
			'payment_coinpal_complaint_status_id',
			'payment_coinpal_chargeback_status_id',
			'payment_coinpal_geo_zone_id',
			'payment_coinpal_status',
			'payment_coinpal_sort_order',
			'payment_coinpal_test',
			'payment_coinpal_3ds'
		];

		foreach ($int_keys as $key) {
			$data[$key] = (string)(int)$data[$key];
		}

		$data['payment_coinpal_total'] = $data['payment_coinpal_total'] === '' ? '0' : (string)$data['payment_coinpal_total'];

		return $data;
	}
}
